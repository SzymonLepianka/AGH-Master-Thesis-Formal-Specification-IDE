# build a Docker image named "docker-image-for-provers" using the Dockerfile in the current directory
docker build -t docker-image-for-provers .